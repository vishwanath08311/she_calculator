import can

class USB2CAN:
    def __init__(self, channel="PCAN_USBBUS1", bitrate=500000):
        """
        Initialize connection to PEAK PCAN-USB adapter.
        Default channel is PCAN_USBBUS1 (first USB port).
        """
        self.channel = channel
        self.bitrate = bitrate
        try:
            self.bus = can.interface.Bus(
                channel=self.channel,
                bustype="pcan",
                bitrate=self.bitrate
            )
            print(f"[USB2CAN] Connected to {self.channel} @ {self.bitrate} bps")
        except Exception as e:
            raise RuntimeError(f"Failed to connect to PCAN device: {e}")

    def send(self, arbitration_id, data):
        """
        Send a CAN frame.
        :param arbitration_id: CAN ID (int)
        :param data: list or bytes of up to 8 bytes
        """
        try:
            msg = can.Message(
                arbitration_id=arbitration_id,
                data=bytearray(data),
                is_extended_id=False
            )
            self.bus.send(msg)
            print(f"[USB2CAN] Sent ID={hex(arbitration_id)} Data={data}")
        except Exception as e:
            print(f"[USB2CAN] Send error: {e}")

    def receive(self, timeout=1.0):
        """
        Receive a CAN frame.
        :param timeout: time in seconds to wait
        :return: can.Message or None
        """
        try:
            msg = self.bus.recv(timeout=timeout)
            if msg:
                print(f"[USB2CAN] Received ID={hex(msg.arbitration_id)} Data={list(msg.data)}")
            return msg
        except Exception as e:
            print(f"[USB2CAN] Receive error: {e}")
            return None
