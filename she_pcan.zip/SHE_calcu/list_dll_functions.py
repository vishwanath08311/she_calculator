import pefile

dll_path = r"C:\KorlanUSB2CAN\usb2can_x64.dll"

pe = pefile.PE(dll_path)
print("Exported functions in the DLL:")
for exp in pe.DIRECTORY_ENTRY_EXPORT.symbols:
    if exp.name:
        print(exp.name.decode())
