import sys, time
from PyQt6.QtWidgets import (
    QApplication, QWidget, QVBoxLayout, QHBoxLayout, QGridLayout,
    QPushButton, QLineEdit, QLabel, QTableWidget, QTableWidgetItem,
    QProgressBar, QGroupBox
)
from PyQt6.QtCore import QThread, pyqtSignal
from she_update_protocol import calculate_m_values  # your SHE backend
from usb2can_wrapper import USB2CAN  # your USB2CAN class

TOTAL_TX_FRAMES = 50
PCAN_CHANNEL = 0x123

# ---------------- PCAN Sender Thread ----------------
class PCANSender(QThread):
    frame_sent = pyqtSignal(object, int)
    error_signal = pyqtSignal(str)

    def __init__(self, can_device, m_values):
        super().__init__()
        self.can = can_device
        self.m_values = m_values
        self.running = False

    def run(self):
        self.running = True
        try:
            frames = ["M1","M2","M3","M4","M5"]
            for i, key in enumerate(frames):
                if not self.running:
                    break
                hex_str = self.m_values[key]
                # Split hex string into 8-byte chunks for CAN
                hex_bytes = bytes.fromhex(hex_str)
                chunks = [hex_bytes[j:j+8] for j in range(0, len(hex_bytes), 8)]
                for c in chunks:
                    self.can.send(PCAN_CHANNEL, c)
                    progress = int(((i+1)/len(frames))*100)
                    self.frame_sent.emit(c, progress)
                    time.sleep(0.2)
        except Exception as e:
            self.error_signal.emit(str(e))

# ---------------- Main GUI ----------------
class SHEPCANGUI(QWidget):
    def __init__(self):
        super().__init__()
        self.setWindowTitle("SHE M1–M5 + PCAN")
        self.resize(1100, 700)
        self.m_values = {}
        self.can_device = USB2CAN()
        self.can_device.open()  # open the device

        main_layout = QHBoxLayout(self)

        # ---------------- Left: Inputs & M1-M5 ----------------
        left_box = QGroupBox("SHE M1–M5 Calculator")
        left_layout = QVBoxLayout(left_box)

        # Input fields
        self.fields = {}
        grid = QGridLayout()
        labels = [
            "KEY_AUTH_ID", "KEY_ID_NEW", "KEY_UPDATE_ENC_C",
            "KEY_UPDATE_MAC_C", "UID_SHE_MODULE", "AuthID", "ID_KEY_SLOT",
            "CID", "FID"
        ]
        for i, label in enumerate(labels):
            grid.addWidget(QLabel(label), i, 0)
            line = QLineEdit()
            self.fields[label] = line
            grid.addWidget(line, i, 1)
        left_layout.addLayout(grid)

        # Calculate button
        self.calc_btn = QPushButton("Calculate M1–M5")
        self.calc_btn.clicked.connect(self.calculate_m)
        left_layout.addWidget(self.calc_btn)

        # M1-M5 table
        self.m_table = QTableWidget(5, 2)
        self.m_table.setHorizontalHeaderLabels(["M", "Value"])
        left_layout.addWidget(self.m_table)

        # Send via PCAN button
        self.send_btn = QPushButton("Send M1–M5 via PCAN")
        self.send_btn.setEnabled(False)
        self.send_btn.clicked.connect(self.send_m)
        left_layout.addWidget(self.send_btn)

        # Status
        self.tx_status = QLabel("Status: Idle")
        left_layout.addWidget(self.tx_status)

        main_layout.addWidget(left_box)

        # ---------------- Right: PCAN TX/RX ----------------
        right_box = QGroupBox("PCAN TX & RX")
        right_layout = QVBoxLayout(right_box)

        # TX table & progress
        self.tx_table = QTableWidget(0, 3)
        self.tx_table.setHorizontalHeaderLabels(["Data", "Progress", "Status"])
        right_layout.addWidget(self.tx_table)
        self.tx_progress = QProgressBar()
        right_layout.addWidget(self.tx_progress)

        main_layout.addWidget(right_box)

    # ---------------- SHE Calculation ----------------
    def calculate_m(self):
        inputs = {}
        try:
            for key, field in self.fields.items():
                val = field.text().strip()
                if not val:
                    raise ValueError(f"{key} is empty")
                if key in ["KEY_AUTH_ID","KEY_ID_NEW","KEY_UPDATE_ENC_C","KEY_UPDATE_MAC_C","FID"]:
                    if val.startswith("0x") or val.startswith("0X"):
                        val = val[2:]
                    inputs[key] = val
                else:
                    inputs[key] = str(int(val))
            self.m_values = calculate_m_values(inputs)
            if "error" in self.m_values:
                raise ValueError(self.m_values["error"])
            # populate table
            for i, key in enumerate(["M1","M2","M3","M4","M5"]):
                self.m_table.setItem(i,0,QTableWidgetItem(key))
                self.m_table.setItem(i,1,QTableWidgetItem(self.m_values[key]))
            self.send_btn.setEnabled(True)
            self.tx_status.setText("Status: M1–M5 Calculated ✅")
        except Exception as e:
            self.tx_status.setText(f"Error: {e}")
            self.send_btn.setEnabled(False)

    # ---------------- Send M1-M5 via PCAN ----------------
    def send_m(self):
        self.send_btn.setEnabled(False)
        self.tx_status.setText("Status: Sending M1–M5 via PCAN...")
        self.tx_table.setRowCount(0)
        self.tx_progress.setValue(0)
        self.tx_worker = PCANSender(self.can_device, self.m_values)
        self.tx_worker.frame_sent.connect(self.update_tx_ui)
        self.tx_worker.error_signal.connect(self.tx_error)
        self.tx_worker.start()

    def update_tx_ui(self, data, progress):
        row = self.tx_table.rowCount()
        self.tx_table.insertRow(row)
        self.tx_table.setItem(row,0,QTableWidgetItem(data.hex()))
        self.tx_table.setItem(row,1,QTableWidgetItem(f"{progress}%"))
        self.tx_table.setItem(row,2,QTableWidgetItem("Sent"))
        self.tx_progress.setValue(progress)
        if progress == 100:
            self.tx_status.setText("Status: M1–M5 Sent ✅")
            self.send_btn.setEnabled(True)

    def tx_error(self, msg):
        self.tx_status.setText(f"TX Error: {msg}")
        self.send_btn.setEnabled(True)


if __name__ == "__main__":
    app = QApplication(sys.argv)
    window = SHEPCANGUI()
    window.show()
    sys.exit(app.exec())
