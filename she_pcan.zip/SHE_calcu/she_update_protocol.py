"""
Secure Hardware Extension (SHE) Calculator Backend
--------------------------------------------------
- Calculates M1..M5 keys based on user inputs
- Ensures calculation happens only when all required inputs are provided
- Provides AES-CMAC, AES-CBC helpers
- Returns error messages if input is invalid
"""

from textwrap import wrap
from Crypto.Cipher import AES
from typing import Dict

# ---------------- AES Helpers ----------------
def AES_MP_Compression(padded_msgs):
    use_key_value = 0x00
    use_key_byte = use_key_value.to_bytes(16, 'big')
    for m in padded_msgs:
        cipher = AES.new(use_key_byte, AES.MODE_ECB)
        cipher_byte = cipher.encrypt(m.to_bytes(16, 'big'))
        use_key_value = int(cipher_byte.hex(), 16) ^ use_key_value ^ m
        use_key_byte = use_key_value.to_bytes(16, 'big')
    return use_key_byte.hex()

def AES_CMAC(KEY, MESSAGE):
    MASK_1bit_ONE = 0x01
    MASK_128bit_ONE = int('f'*32,16)
    CONST_R128 = 0x87
    CONST_ZERO = 0x00

    key_byte = bytes.fromhex(KEY)
    cipher = AES.new(key_byte, AES.MODE_ECB)
    L = int(cipher.encrypt(CONST_ZERO.to_bytes(16,'big')).hex(),16)

    def generate_subkey(val):
        msb = (val >> 127) & MASK_1bit_ONE
        return (val << 1) ^ CONST_R128 if msb else val << 1

    K1 = generate_subkey(L)
    K2 = generate_subkey(K1)
    K1 = (K1 & MASK_128bit_ONE).to_bytes(16, 'big').hex()
    K2 = (K2 & MASK_128bit_ONE).to_bytes(16, 'big').hex()

    blocks = [int(m,16) if m else 0 for m in MESSAGE]
    mac = b'\x00'
    for i in range(len(blocks)-1):
        xor_block = int(mac.hex(),16) ^ blocks[i]
        mac = cipher.encrypt(xor_block.to_bytes(16,'big'))

    last = blocks[-1]
    bit_len = len(MESSAGE[-1]) * 4
    if bit_len < 128:
        pad = 128 - bit_len - 1
        last_bin = bin(last)[2:] + '1' + '0'*pad
        last_padded = int(last_bin,2)
        xor_block = int(mac.hex(),16) ^ last_padded ^ int(K2,16)
    else:
        xor_block = int(mac.hex(),16) ^ last ^ int(K1,16)

    mac = cipher.encrypt(xor_block.to_bytes(16,'big'))
    return mac.hex()

# ---------------- M1-M5 Calculation ----------------
def calculate_m_values(inputs: Dict[str,str]) -> Dict[str,str]:
    required_keys = [
        'KEY_AUTH_ID', 'KEY_ID_NEW', 'KEY_UPDATE_ENC_C',
        'KEY_UPDATE_MAC_C', 'UID_SHE_MODULE', 'AuthID',
        'ID_KEY_SLOT', 'CID', 'FID'
    ]

    # Validate inputs
    for key in required_keys:
        if key not in inputs or not inputs[key].strip():
            return {
                "M1": "", "M2": "", "M3": "", "M4": "", "M5": "",
                "error": f"Input '{key}' is missing or empty"
            }

    try:
        # Convert inputs to proper integers
        KEY_AUTH_ID      = int(inputs['KEY_AUTH_ID'], 16)
        KEY_ID_NEW       = int(inputs['KEY_ID_NEW'], 16)
        KEY_UPDATE_ENC_C = int(inputs['KEY_UPDATE_ENC_C'], 16)
        KEY_UPDATE_MAC_C = int(inputs['KEY_UPDATE_MAC_C'], 16)
        UID_SHE_MODULE   = int(inputs['UID_SHE_MODULE'], 16)
        AuthID           = int(inputs['AuthID'])
        ID_KEY_SLOT      = int(inputs['ID_KEY_SLOT'])
        CID              = int(inputs['CID'])
        FID              = inputs['FID']

        # --- M1-M5 Computation ---
        K1 = AES_MP_Compression([KEY_AUTH_ID, KEY_UPDATE_ENC_C])
        K2 = AES_MP_Compression([KEY_AUTH_ID, KEY_UPDATE_MAC_C])
        K3 = AES_MP_Compression([KEY_ID_NEW, KEY_UPDATE_ENC_C])
        K4 = AES_MP_Compression([KEY_ID_NEW, KEY_UPDATE_MAC_C])

        UID_BIT_LEN = 120
        uid_bytes = UID_SHE_MODULE.to_bytes(UID_BIT_LEN // 8, 'big')
        M1 = uid_bytes.hex() + str(ID_KEY_SLOT) + str(AuthID)

        FID_BIT_LEN = 5
        CID_BIT_LEN = 28
        CID_BIN_STR = bin(CID)[2:].zfill(CID_BIT_LEN)
        ZERO_FILL = '0' * (128 - CID_BIT_LEN - FID_BIT_LEN)
        INPUT_BLOCK_1 = int(CID_BIN_STR + FID + ZERO_FILL, 2)
        iv_bytes = (0).to_bytes(16, 'big')
        cipher_input = INPUT_BLOCK_1.to_bytes(16,'big') + KEY_ID_NEW.to_bytes(16,'big')
        cipher = AES.new(bytes.fromhex(K1), AES.MODE_CBC, iv_bytes)
        M2 = cipher.encrypt(cipher_input).hex()

        MESSAGE_IN = [M1] + wrap(M2,32)
        M3 = AES_CMAC(K2, MESSAGE_IN)

        CID_PAD = '1' + '0' * (128-1-CID_BIT_LEN)
        CID_FULL = int(CID_BIN_STR + CID_PAD,2).to_bytes(16,'big')
        M4_STAR = AES.new(bytes.fromhex(K3), AES.MODE_ECB).encrypt(CID_FULL).hex()
        M4 = AES_CMAC(K3, [M1, M4_STAR])
        M5 = AES_CMAC(K4, [M1, M4_STAR])

        return {"M1": M1, "M2": M2, "M3": M3, "M4": M4, "M5": M5}

    except Exception as e:
        return {"M1":"ERROR","M2":"ERROR","M3":"ERROR","M4":"ERROR","M5":"ERROR","error":str(e)}
