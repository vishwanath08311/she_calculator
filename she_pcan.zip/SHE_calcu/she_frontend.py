"""
SHE Calculator + Korlan CAN Integration (Safe Version)
------------------------------------------------------
- Computes M1..M5 using she_update_protocol
- Sends values as CAN frames via Korlan (usb2can)
- GUI remains responsive using QThread
- Safe CanalOpen with timeout to avoid crashes
"""

import sys
import os
import ctypes
import time
from PyQt6.QtWidgets import (
    QApplication, QWidget, QVBoxLayout, QHBoxLayout, QPushButton, QGroupBox,
    QFormLayout, QLineEdit, QTextEdit, QSpinBox, QCheckBox, QMessageBox
)
from PyQt6.QtCore import Qt, QThread, pyqtSignal
import she_update_protocol as she
import threading

# ---------------- Korlan Safe Wrapper ----------------
class KorlanDevice:
    def __init__(self, dll_path=r"C:\KorlanUSB2CAN\usb2can_x64.dll", bitrate=500000):
        self.dll_path = dll_path
        self.bitrate = bitrate
        self.dll = None
        self.handle = None
        self.load_dll()

    def load_dll(self):
        print("🔹 Checking DLL path...")
        if not os.path.exists(self.dll_path):
            raise FileNotFoundError(f"DLL not found: {self.dll_path}")
        print(f"✅ DLL found at {self.dll_path}")

        try:
            print("🔹 Loading DLL...")
            self.dll = ctypes.WinDLL(self.dll_path)
            print("✅ DLL loaded successfully")
        except Exception as e:
            print(f"❌ Failed to load DLL: {e}")
            raise

        # ---------------- Set CanalOpen ----------------
        try:
            self.dll.CanalOpen.argtypes = [ctypes.c_uint]
            self.dll.CanalOpen.restype = ctypes.c_uint
            print("✅ CanalOpen types set")
        except Exception as e:
            print(f"❌ Error setting CanalOpen types: {e}")

        # ---------------- Set CanalSend ----------------
        try:
            self.dll.CanalSend.argtypes = [ctypes.c_uint, ctypes.c_uint,
                                           ctypes.POINTER(ctypes.c_ubyte), ctypes.c_uint]
            self.dll.CanalSend.restype = ctypes.c_int
            print("✅ CanalSend types set")
        except Exception as e:
            print(f"❌ Error setting CanalSend types: {e}")

        # ---------------- Set CanalClose ----------------
        try:
            self.dll.CanalClose.argtypes = [ctypes.c_uint]
            self.dll.CanalClose.restype = ctypes.c_int
            print("✅ CanalClose types set")
        except Exception as e:
            print(f"❌ Error setting CanalClose types: {e}")

        # ---------------- Set CanalSetBaudrate ----------------
        try:
            self.dll.CanalSetBaudrate.argtypes = [ctypes.c_uint, ctypes.c_uint]
            self.dll.CanalSetBaudrate.restype = ctypes.c_int
            print("✅ CanalSetBaudrate types set")
        except Exception as e:
            print(f"❌ Error setting CanalSetBaudrate types: {e}")

        print("🔹 DLL initialization complete")

    def open_device(self, index=0, timeout=5):
        """Open device safely with timeout to avoid hanging"""
        self.handle = None
        exception_holder = []

        def target():
            try:
                self.handle = self.dll.CanalOpen(index)
            except Exception as e:
                exception_holder.append(e)

        t = threading.Thread(target=target)
        t.start()
        t.join(timeout=timeout)
        if t.is_alive():
            raise TimeoutError("CanalOpen is hanging! Check device/driver.")
        if exception_holder:
            raise exception_holder[0]
        if self.handle == 0:
            raise RuntimeError(f"Failed to open Korlan device at index {index}")

        # Set bitrate
        self.dll.CanalSetBaudrate(self.handle, self.bitrate)

    def send_frame(self, can_id, data_bytes):
        if not self.handle:
            raise RuntimeError("Device not opened")
        frame = (ctypes.c_ubyte * 8)(*data_bytes.ljust(8, b'\x00'))
        res = self.dll.CanalSend(self.handle, can_id, frame, len(data_bytes))
        return res == 1

    def close(self):
        if self.handle:
            self.dll.CanalClose(self.handle)
            self.handle = None

# ---------------- CAN Thread ----------------
class KorlanSendThread(QThread):
    frame_sent = pyqtSignal(str)
    finished = pyqtSignal()

    def __init__(self, m_values, device: KorlanDevice, interval=0.05):
        super().__init__()
        self.m_values = m_values
        self.device = device
        self.interval = interval
        self.running = True

    def run(self):
        can_id = 0x500
        try:
            for key in ["M1", "M2", "M3", "M4", "M5"]:
                if not self.running:
                    break
                if key not in self.m_values or not self.m_values[key]:
                    self.frame_sent.emit(f"⚠️ {key} missing or empty, skipping")
                    continue
                try:
                    data_bytes = bytes.fromhex(self.m_values[key])
                    self.frame_sent.emit(f"Preparing {key}: {data_bytes.hex().upper()}")
                except Exception as e:
                    self.frame_sent.emit(f"❌ Failed to convert {key} to bytes: {e}")
                    continue

                for i in range(0, len(data_bytes), 8):
                    if not self.running:
                        break
                    chunk = data_bytes[i:i+8]
                    if self.device.send_frame(can_id, chunk):
                        self.frame_sent.emit(f"✅ Sent {key} frame {i//8+1}: {chunk.hex().upper()}")
                    else:
                        self.frame_sent.emit(f"❌ Failed to send {key} frame {i//8+1}")
                    time.sleep(self.interval)
                can_id += 1
        except Exception as e:
            self.frame_sent.emit(f"❌ Exception in CAN thread: {e}")
        finally:
            self.finished.emit()

    def stop(self):
        self.running = False
        self.frame_sent.emit("⏹ Transmission stopped by user")

# ---------------- SHE GUI ----------------
class SHEKeyUpdateTab(QWidget):
    def __init__(self):
        super().__init__()
        self.m_values = {}
        self.thread = None
        self.device = None
        self.init_ui()

    def init_ui(self):
        layout = QVBoxLayout()
        layout.setSpacing(10)

        # Key Inputs
        key_group = QGroupBox("🔐 Key Inputs")
        key_layout = QFormLayout()
        self.authKey = QLineEdit()
        self.newKey = QLineEdit()
        self.encC = QLineEdit()
        self.macC = QLineEdit()
        key_layout.addRow("KEY_AUTH_ID:", self.authKey)
        key_layout.addRow("KEY_ID_NEW:", self.newKey)
        key_layout.addRow("KEY_UPDATE_ENC_C:", self.encC)
        key_layout.addRow("KEY_UPDATE_MAC_C:", self.macC)
        key_group.setLayout(key_layout)
        layout.addWidget(key_group)

        # Identifiers
        id_group = QGroupBox("🆔 Identifiers & Counter")
        id_layout = QFormLayout()
        self.authID = QSpinBox(); self.authID.setRange(0, 15)
        self.keySlot = QSpinBox(); self.keySlot.setRange(0, 15)
        self.uid = QLineEdit(); self.uid.setPlaceholderText("UID_SHE_MODULE (Hex)")
        self.cid = QSpinBox(); self.cid.setRange(0, 999999)
        id_layout.addRow("AuthID:", self.authID)
        id_layout.addRow("Key Slot:", self.keySlot)
        id_layout.addRow("UID:", self.uid)
        id_layout.addRow("Counter (CID):", self.cid)
        id_group.setLayout(id_layout)
        layout.addWidget(id_group)

        # Flags
        flags_group = QGroupBox("⚙️ Flags")
        flags_layout = QHBoxLayout()
        self.flag_write = QCheckBox("WRITE")
        self.flag_boot = QCheckBox("BOOT")
        self.flag_debug = QCheckBox("DEBUG")
        self.flag_usage = QCheckBox("USAGE")
        self.flag_wild = QCheckBox("WILDCARD")
        for f in [self.flag_write, self.flag_boot, self.flag_debug, self.flag_usage, self.flag_wild]:
            flags_layout.addWidget(f)
        flags_group.setLayout(flags_layout)
        layout.addWidget(flags_group)

        # Calculate Button
        calc_btn = QPushButton("🧮 Calculate M1–M5")
        calc_btn.clicked.connect(self.calculate_m_values)
        layout.addWidget(calc_btn, alignment=Qt.AlignmentFlag.AlignCenter)

        # Output
        self.output = QTextEdit(); self.output.setReadOnly(True); self.output.setFixedHeight(200)
        layout.addWidget(self.output)

        # Send Section
        send_group = QGroupBox("📡 Send via Korlan")
        send_layout = QVBoxLayout()
        self.send_button = QPushButton("🚀 Send M1–M5")
        self.stop_button = QPushButton("⏹ Stop Sending")
        self.stop_button.setEnabled(False)
        self.send_button.clicked.connect(self.send_m_values)
        self.stop_button.clicked.connect(self.stop_sending)
        send_layout.addWidget(self.send_button)
        send_layout.addWidget(self.stop_button)
        send_group.setLayout(send_layout)
        layout.addWidget(send_group)

        # Log
        log_group = QGroupBox("📝 CAN Log")
        log_layout = QVBoxLayout()
        self.log_output = QTextEdit(); self.log_output.setReadOnly(True)
        log_layout.addWidget(self.log_output)
        log_group.setLayout(log_layout)
        layout.addWidget(log_group)

        self.setLayout(layout)

    def get_flags(self):
        return ''.join(['1' if cb.isChecked() else '0' for cb in
                        [self.flag_write, self.flag_boot, self.flag_debug, self.flag_usage, self.flag_wild]])

    def calculate_m_values(self):
        try:
            inputs = {
                "KEY_AUTH_ID": self.authKey.text().strip(),
                "KEY_ID_NEW": self.newKey.text().strip(),
                "KEY_UPDATE_ENC_C": self.encC.text().strip(),
                "KEY_UPDATE_MAC_C": self.macC.text().strip(),
                "AuthID": str(self.authID.value()),
                "ID_KEY_SLOT": str(self.keySlot.value()),
                "UID_SHE_MODULE": self.uid.text().strip(),
                "FID": self.get_flags(),
                "CID": str(self.cid.value())
            }
            result = she.calculate_m_values(inputs)
            self.m_values = result
            self.output.setPlainText(
                "\n".join(f"{k}: {v}" for k, v in result.items())
            )
            QMessageBox.information(self, "Success", "M1–M5 calculated successfully!")
        except Exception as e:
            QMessageBox.critical(self, "Error", f"Calculation failed: {e}")

    def send_m_values(self):
        if not self.m_values:
            QMessageBox.warning(self, "Warning", "Calculate M1–M5 first!")
            return

        # Open device safely
        try:
            self.device = KorlanDevice()
            self.device.open_device(index=0, timeout=3)
            self.log_output.append("✅ Korlan device opened successfully")
        except Exception as e:
            QMessageBox.critical(self, "Error", f"Failed to open Korlan device:\n{e}")
            return

        # Start CAN thread
        self.thread = KorlanSendThread(self.m_values, self.device)
        self.thread.frame_sent.connect(self.log_frame)
        self.thread.finished.connect(self.on_send_finished)
        self.send_button.setEnabled(False)
        self.stop_button.setEnabled(True)
        self.thread.start()

    def stop_sending(self):
        if self.thread:
            self.thread.stop()
            self.stop_button.setEnabled(False)

    def log_frame(self, message):
        self.log_output.append(message)
        print(message)

    def on_send_finished(self):
        self.send_button.setEnabled(True)
        self.stop_button.setEnabled(False)
        if self.device:
            self.device.close()
            self.log_output.append("✅ Korlan device closed")
        QMessageBox.information(self, "Done", "CAN frames transmission completed!")

# ---------------- Main ----------------
if __name__ == "__main__":
    app = QApplication(sys.argv)
    window = SHEKeyUpdateTab()
    window.setWindowTitle("🔐 SHE Calculator + Korlan CAN")
    window.resize(600, 900)
    window.show()
    sys.exit(app.exec())
