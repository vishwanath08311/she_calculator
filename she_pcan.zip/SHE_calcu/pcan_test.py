import sys
import time
import random
import can
from PyQt6.QtWidgets import (
    QApplication, QWidget, QVBoxLayout, QPushButton,
    QTableWidget, QTableWidgetItem, QProgressBar, QLabel, QHBoxLayout, QGroupBox
)
from PyQt6.QtCore import QThread, pyqtSignal

PCAN_CHANNEL = "PCAN_USBBUS1"
PCAN_BITRATE = 500000
TOTAL_TX_FRAMES = 50  # Number of frames TX will send


class CANSender(QThread):
    frame_sent = pyqtSignal(object, int)
    error_signal = pyqtSignal(str)

    def __init__(self, bus, total_frames=TOTAL_TX_FRAMES):
        super().__init__()
        self.bus = bus
        self.running = False
        self.count = 0
        self.total_frames = total_frames

    def run(self):
        self.running = True
        try:
            while self.running and self.count < self.total_frames:
                payload = [random.randint(0, 255) for _ in range(8)]
                msg = can.Message(
                    arbitration_id=0x123 + (self.count % 10),
                    data=payload,
                    is_extended_id=False
                )
                try:
                    self.bus.send(msg)
                except can.CanError as e:
                    self.error_signal.emit(f"TX Send Error: {e}")
                    break

                self.count += 1
                progress = int((self.count / self.total_frames) * 100)
                msg.timestamp = time.time()
                msg.channel = PCAN_CHANNEL
                self.frame_sent.emit(msg, progress)
                time.sleep(0.2)  # small delay for TX
        except Exception as e:
            self.error_signal.emit(f"TX Thread Error: {e}")


class CANReceiver(QThread):
    frame_received = pyqtSignal(object, int)
    error_signal = pyqtSignal(str)

    def __init__(self, bus, total_expected_frames=TOTAL_TX_FRAMES):
        super().__init__()
        self.bus = bus
        self.running = False
        self.total_expected_frames = total_expected_frames
        self.received_count = 0

    def run(self):
        self.running = True
        try:
            while self.running and self.received_count < self.total_expected_frames:
                msg = self.bus.recv(timeout=1.0)
                if msg:
                    msg.timestamp = time.time()
                    msg.channel = PCAN_CHANNEL
                    self.received_count += 1
                    progress = int((self.received_count / self.total_expected_frames) * 100)
                    self.frame_received.emit(msg, progress)
                    time.sleep(0.05)  # small delay for RX processing
        except Exception as e:
            self.error_signal.emit(f"RX Thread Error: {e}")


class CANUI(QWidget):
    def __init__(self):
        super().__init__()
        self.setWindowTitle("PCAN TX & RX")
        self.resize(1000, 600)
        layout = QHBoxLayout(self)

        # --- TX Section ---
        tx_group = QGroupBox("Transmit (TX)")
        tx_layout = QVBoxLayout(tx_group)
        self.tx_start_btn = QPushButton("Start Transfer")
        self.tx_start_btn.clicked.connect(self.start_tx)
        tx_layout.addWidget(self.tx_start_btn)
        self.tx_progress = QProgressBar()
        tx_layout.addWidget(self.tx_progress)
        self.tx_table = QTableWidget(0, 6)
        self.tx_table.setHorizontalHeaderLabels(["Direction", "Timestamp", "ID", "DLC", "Data", "Channel"])
        tx_layout.addWidget(self.tx_table)
        self.tx_status = QLabel("Status: Idle")
        tx_layout.addWidget(self.tx_status)

        # --- RX Section ---
        rx_group = QGroupBox("Receive (RX)")
        rx_layout = QVBoxLayout(rx_group)
        self.rx_start_btn = QPushButton("Start Receiving")
        self.rx_start_btn.clicked.connect(self.start_rx)
        rx_layout.addWidget(self.rx_start_btn)
        self.rx_progress = QProgressBar()
        rx_layout.addWidget(self.rx_progress)
        self.rx_table = QTableWidget(0, 6)
        self.rx_table.setHorizontalHeaderLabels(["Direction", "Timestamp", "ID", "DLC", "Data", "Channel"])
        rx_layout.addWidget(self.rx_table)
        self.rx_status = QLabel("Status: Idle")
        rx_layout.addWidget(self.rx_status)

        layout.addWidget(tx_group)
        layout.addWidget(rx_group)

        self.tx_worker = None
        self.rx_worker = None

        # --- Shared Bus with loopback enabled ---
        try:
            self.bus = can.interface.Bus(
                interface="pcan",
                channel=PCAN_CHANNEL,
                bitrate=PCAN_BITRATE,
                receive_own_messages=True  # receive your own TX frames
            )
        except can.CanInitializationError as e:
            self.tx_status.setText(f"Bus Init Error: {e}")
            self.rx_status.setText(f"Bus Init Error: {e}")
            self.tx_start_btn.setEnabled(False)
            self.rx_start_btn.setEnabled(False)
            self.bus = None

    # --- TX Methods ---
    def start_tx(self):
        if not self.bus:
            return
        self.tx_table.setRowCount(0)
        self.tx_progress.setValue(0)
        self.tx_status.setText("Status: Transferring...")
        self.tx_start_btn.setEnabled(False)

        self.tx_worker = CANSender(bus=self.bus, total_frames=TOTAL_TX_FRAMES)
        self.tx_worker.frame_sent.connect(self.update_tx_ui)
        self.tx_worker.error_signal.connect(self.tx_error)
        self.tx_worker.finished.connect(self.tx_finished)
        self.tx_worker.start()

    def update_tx_ui(self, msg, progress):
        row = self.tx_table.rowCount()
        self.tx_table.insertRow(row)
        data_str = " ".join(f"{b:02X}" for b in msg.data)
        self.tx_table.setItem(row, 0, QTableWidgetItem("TX"))
        self.tx_table.setItem(row, 1, QTableWidgetItem(f"{msg.timestamp:.6f}"))
        self.tx_table.setItem(row, 2, QTableWidgetItem(f"0x{msg.arbitration_id:03X}"))
        self.tx_table.setItem(row, 3, QTableWidgetItem(str(msg.dlc)))
        self.tx_table.setItem(row, 4, QTableWidgetItem(data_str))
        self.tx_table.setItem(row, 5, QTableWidgetItem(msg.channel))
        self.tx_progress.setValue(progress)

    def tx_finished(self):
        self.tx_status.setText("Status: Transfer Complete ✅")
        self.tx_start_btn.setEnabled(True)

    def tx_error(self, msg):
        self.tx_status.setText(msg)
        self.tx_start_btn.setEnabled(True)

    # --- RX Methods ---
    def start_rx(self):
        if not self.bus:
            return
        self.rx_table.setRowCount(0)
        self.rx_progress.setValue(0)
        self.rx_status.setText("Status: Receiving...")
        self.rx_start_btn.setEnabled(False)

        self.rx_worker = CANReceiver(bus=self.bus, total_expected_frames=TOTAL_TX_FRAMES)
        self.rx_worker.frame_received.connect(self.update_rx_ui)
        self.rx_worker.error_signal.connect(self.rx_error)
        self.rx_worker.finished.connect(self.rx_finished)
        self.rx_worker.start()

    def update_rx_ui(self, msg, progress):
        row = self.rx_table.rowCount()
        self.rx_table.insertRow(row)
        data_str = " ".join(f"{b:02X}" for b in msg.data)
        self.rx_table.setItem(row, 0, QTableWidgetItem("RX"))
        self.rx_table.setItem(row, 1, QTableWidgetItem(f"{msg.timestamp:.6f}"))
        self.rx_table.setItem(row, 2, QTableWidgetItem(f"0x{msg.arbitration_id:03X}"))
        self.rx_table.setItem(row, 3, QTableWidgetItem(str(msg.dlc)))
        self.rx_table.setItem(row, 4, QTableWidgetItem(data_str))
        self.rx_table.setItem(row, 5, QTableWidgetItem(msg.channel))
        self.rx_progress.setValue(progress)

    def rx_finished(self):
        self.rx_status.setText("Status: Receive Complete ✅")
        self.rx_start_btn.setEnabled(True)

    def rx_error(self, msg):
        self.rx_status.setText(msg)
        self.rx_start_btn.setEnabled(True)


if __name__ == "__main__":
    app = QApplication(sys.argv)
    window = CANUI()
    window.show()
    sys.exit(app.exec())
